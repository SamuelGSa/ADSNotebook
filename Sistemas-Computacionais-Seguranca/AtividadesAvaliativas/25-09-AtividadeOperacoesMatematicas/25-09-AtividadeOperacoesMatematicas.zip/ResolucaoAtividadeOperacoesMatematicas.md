# Atividade Operações Matemáticas

1) Fazer as seguintes adições em binário

a) 10010 + 10011 = 100101
b) 10010 + 11000 = 101010
c) 11010 + 11100 = 110110
d) 110111 + 1111 = 1000110

2) Fazer as seguintes subtrações em binário
a) 10010 - 1001 = 1001
b) 10010 - 1100 = 110
c) 11010 - 111 = 10011
e) 110111 - 1111 = 101000

---
3) Fazer as seguintes adições em octal
a) 3456 + 337 = 4015
b) 12345 + 7654 = 22221
c) 12844 + 377 = OCTAL INVÁLIDO (12844)
d) 7344 + 666 = 10232

4) Fazer as seguintes subtrações em octal
a) 4754 – 1234 = 3520
b) 7543 – 345 = 7176
c) 6433 – 234 = 6177
d) 77754 – 7345 = 70407

---
5) Fazer as seguintes adições em hexadecimal 
a) AB123 + 1001 = ac124
b) ABC1 + 8B12 = 136d3
c) 89AB + AB9 = 9464
d) 8AB9 + BC = 8b75

6) Fazer as seguintes subtrações em hexadecimal 
a) AB123 - 1001 = aa122
b) ABC1 - 8B12 = 20af
c) 89AB - AB9 = 7ef2
d) 8AB9 - BC = 89fd

7) Fazer as seguintes operações
a)AB416 + 10112     =  (     )8
b)AC8316 - 1112     =  (     )8
c) 1011110 + 10116   =  (    )2  
d) 1010112 - 1910     =  (    )16
e) 47738 - 1916     =  (     )2
f) 46758 – 10112     =  (     )16

NAO É INFORMADO QUAL A BASE DOS VALORES, LOGO, NÃO É POSSIVEL FAZER A CONVERSÃO DOS VALORES E NEM A SOMA. 
